package backend;

@SuppressWarnings("serial")
public class GradebookException extends Exception{

	public GradebookException(String message){
		super(message);
	}
}
