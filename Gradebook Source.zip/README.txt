This code uses Apache POI libraries, and will not function without them, so if you would like to use this source, you'll also need to download Apache POI:

https://poi.apache.org/download.html#POI-3.17